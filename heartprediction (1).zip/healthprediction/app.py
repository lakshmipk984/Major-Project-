from flask import Flask, render_template, request, url_for
import matplotlib.pyplot as plt
import os

app = Flask(__name__)


# Dummy model class to simulate .predict()
class DummyModel:
    def predict(self, features):
        age, chol = features[0], features[4]
        if age > 50 and chol > 200:
            return "Yes, you may have heart disease."
        else:
            return "No, you may not have heart disease."


# Instantiate dummy model
model = DummyModel()


# Graph generator function with line graph
def generate_graph(trestbps, fbs, thalach, exang, oldpeak):
    labels = ['Blood Pressure', 'FBS', 'Thalach', 'Exang', 'Oldpeak']
    values = [trestbps, fbs, thalach, exang, oldpeak]

    plt.figure(figsize=(8, 5))

    # Create a line graph
    plt.plot(labels, values, marker='o', linestyle='-', color='b', markersize=8)

    plt.title('Blood Pressure and Other Factors')
    plt.ylabel('Value')
    plt.tight_layout()

    # Save graph in static folder
    graph_path = os.path.join('static', 'graph.png')
    plt.savefig(graph_path)
    plt.close()

    return 'graph.png'


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/result", methods=["POST"])
def result():
    form_data = request.form

    # Extract and convert input values
    age = int(form_data["age"])
    sex = int(form_data["sex"])
    cp = int(form_data["cp"])
    trestbps = int(form_data["trestbps"])
    chol = int(form_data["chol"])
    fbs = int(form_data["fbs"])
    restecg = int(form_data["restecg"])
    thalach = int(form_data["thalach"])
    exang = int(form_data["exang"])
    oldpeak = float(form_data["oldpeak"])
    slope = int(form_data["slope"])
    ca = int(form_data["ca"])
    thal = int(form_data["thal"])

    # Prepare input for model
    input_data = [age, sex, cp, trestbps, chol, fbs, restecg,
                  thalach, exang, oldpeak, slope, ca, thal]

    # Predict using dummy model
    prediction = model.predict(input_data)

    # Generate graph and get filename
    graph_name = generate_graph(trestbps, fbs, thalach, exang, oldpeak)

    # Keep only key fields for display
    display_data = {
        "age": age,
        "sex": sex,
        "cp": cp
    }

    return render_template("result.html", prediction=prediction, graph_name=graph_name, form_data=display_data)


if __name__ == "__main__":
    app.run(debug=True)
